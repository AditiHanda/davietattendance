<?php
require "start.php";

$teacher_id=$_POST["teacher_id"];
$teacher_password=$_POST["teacher_password"];

$sql_query = "select * from teachers where teacher_id='$teacher_id' and teacher_password='$teacher_password';";
$result =mysqli_query($con,$sql_query);
while($row = mysqli_fetch_assoc($result))
{
echo "Login Success";
}
?>