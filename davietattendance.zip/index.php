<html>
<head><title>Daviet Attendance</title></head>
<style>

body {font-family: Arial, Helvetica, sans-serif; }
form {border: 3px solid #f1f1f1;
}
.bg-img {
  /* The image used */
  background-image: url("maxresdefault.jpg");

  min-height: 640px;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
}
.container1{
position: absolute;
  right: 508px;
  margin: 3px;
  max-width: 300px;
  padding: 16px;

  background-color: white;
    
}

input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  /* margin: 8px 0; */
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: rgb(168, 59, 59);
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 2px 77px;
  background-color: #f44336;
  
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
      }

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}


</style>
<body   class="n1">
<div class="n1">
</div>
<div class="bg-img">
<form  class="container1" method="POST" action="login.php">
    <div class="imgcontainer">
      <img src="download.jpg" alt="Avatar" class="avatar">
    </div>
  
    <div class="container">
      <label for="uname"><b>ID</b></label>
      <input type="text" placeholder="Enter Username" name="id" >
  
      <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="password" >
          
      <button type="submit">Login</button>
      <label>
        <input type="checkbox" checked="checked" name="remember"> Remember me
      </label>
    </div>
  
    <div class="container" style="background-color:#f1f1f1">
      <button type="submit" class="cancelbtn" formaction="signup.php"   > Sign Up for Student</button><br>
      <button type="submit" class="cancelbtn" formaction="signup1.php"   > Sign Up for Teachers</button>
        <button type="submit" class="cancelbtn" formaction="signup2.php"   > Register new Subjects</button>
      <span class="psw">Forgot <a href="#">password?</a></span>
    </div>
    </div>
  </form>
</body>
</html>