<?php
require "start.php";

// $student_id=$_POST["student_id"];
// $subject_id=$_POST["subject_id"];
$student_id='Nishant';
$subject_id='su2';

$sql_query = "select sum(attendance_status='PRESENT')*100/count(*) as attendance_percent from attendance where student_id='$student_id' and subject_id='$subject_id';";
$sql_query2 = "select max(time),attendance_status from attendance where student_id='$student_id' and subject_id='$subject_id';";
$result =mysqli_query($con,$sql_query);
$result2=mysqli_query($con,$sql_query2);
while($row = mysqli_fetch_assoc($result))
{
echo $row['attendance_percent'];
echo"%";
echo"\n";
}
while($row = mysqli_fetch_assoc($result2))
{
    echo "Last marked attendance at: ";
    echo $row['max(time)'];
    echo "\n";
    echo "Attendance Status: ";
    echo $row['attendance_status'];
}
?>