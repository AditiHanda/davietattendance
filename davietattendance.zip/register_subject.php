<?php
require "start.php";
	$subject_id=$_POST["subject_id"];
	$subject_name=$_POST["subject_name"];
	$subject_year=$_POST["subject_year"];
//$sql_query = "INSERT INTO `subjects` (`subject_id`, `subject_name`, `subject_year`) VALUES (`$subject_id`, `$subject_name`, `$subject_year`);";

$sql_query = "INSERT INTO `subjects` (`subject_id`, `subject_name`, `subject_year`) VALUES ('$subject_id', '$subject_name', '$subject_year');";

if(mysqli_query($con,$sql_query))
{
echo "Subject Register Success";
}
else
{
echo "Subject Register Unsuccess";
}
?>