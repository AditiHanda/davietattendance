<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Student Login</title>

        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">
        <link rel="stylesheet" href="form.css" >
        <script src="form.js"></script>
        <link rel="stylesheet" href="contactcss.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="css/fontAwesome.css">
        <link rel="stylesheet" href="css/light-box.css">
        <link rel="stylesheet" href="css/templatemo-main.css">

        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

        <script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
<style>
table,th,td{
    border:1px solid white;
    font-size:20px;
    color:white;
    font-weight:bold;
}


</style>
<body>
    
    <div class="sequence">
  
      <div class="seq-preloader">
        <svg width="39" height="16" viewBox="0 0 39 16" xmlns="http://www.w3.org/2000/svg" class="seq-preload-indicator"><g fill="#F96D38"><path class="seq-preload-circle seq-preload-circle-1" d="M3.999 12.012c2.209 0 3.999-1.791 3.999-3.999s-1.79-3.999-3.999-3.999-3.999 1.791-3.999 3.999 1.79 3.999 3.999 3.999z"/><path class="seq-preload-circle seq-preload-circle-2" d="M15.996 13.468c3.018 0 5.465-2.447 5.465-5.466 0-3.018-2.447-5.465-5.465-5.465-3.019 0-5.466 2.447-5.466 5.465 0 3.019 2.447 5.466 5.466 5.466z"/><path class="seq-preload-circle seq-preload-circle-3" d="M31.322 15.334c4.049 0 7.332-3.282 7.332-7.332 0-4.049-3.282-7.332-7.332-7.332s-7.332 3.283-7.332 7.332c0 4.05 3.283 7.332 7.332 7.332z"/></g></svg>
      </div>
      
    </div>
    
  
        <nav>
          
          <ul>
            <li style="color:white; font-size: 16px">  <em><b><?php echo $_POST['student_name'];?></em></b></em></li>
            <li><a href="#1"><i class="fa fa-home"></i> <em>PROFILE</em></a></li>
            <li><a href="#2"><i class="fa fa-user"></i> <em>SUBJECTS</em></a></li>
            <li><a href="#3"><i class="fa fa-pencil"></i> <em>ATTENDANCE</em></a></li>
            <li><a href="index.php" onclick='logOut();'><i class="fa fa-sign-out"></i> <em>LOG-OUT</em></a></li>
          </ul>
        </nav>
        
        <div class="slides">
          <div class="slide" id="1">
            <div class="content first-content">
              <div class="container-fluid">
                  <div class="col-md-3">
                    
                  </div>
                  <div class="col-md-9">
                   <div class="left-content">
                      <h2>PROFILE</h2>
                     <p> <em>Name</em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" disabled value=<?php echo $_POST['student_name'];?> style= "background: transparent ;border: none;border-bottom: 1px solid white;"/><br>
                     
                      <em>Batch</em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" disabled value=<?php echo $_POST['student_batch'];?> style= "background: transparent ;border: none;border-bottom: 1px solid white;"/><br>
                      <em>Roll No.</em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" disabled value=<?php echo $_POST['student_id'];?> style= "background: transparent ;border: none;border-bottom: 1px solid white;"/><br>
                      <!--<em>Address</em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" style= "background: transparent ;border: none;border-bottom: 1px solid white;"/><br>
                      <em>E-mail</em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" style= "background: transparent ;border: none;border-bottom: 1px solid white;"/><br>-->
                      <em>Contact No.</em>&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" disabled value=<?php echo $_POST['student_contact'];?> style= "background: transparent ;border: none;border-bottom: 1px solid white;"/><br></p>
                      </div>
                      </div>
              </div>
            </div>
          </div>
          <div class="slide" id="2">
            <div class="content second-content">
                <div class="container-fluid">
                    <div class="col-md-6">
                        <div class="left-content">
                            <h2>SUBJECTS</h2>
<?php
require "start.php";

$student_id=$_POST["student_id"];

$sql_query = "select * from teacher_student_subject where student_id='$student_id';";
$result =mysqli_query($con,$sql_query);
while($row = mysqli_fetch_assoc($result))
{
//echo "true;";
//echo $row['subject_id'];
//echo "\n";
//}
?>
                          
                          <div class="main-btn"><a href="#3"> <?php echo $row['subject_id']; ?></a></div><br><?php } ?>                          
                          <!--<div class="main-btn"><a href="#3">SUBJECT1</a></div><BR>
                            <div class="main-btn"><a href="#3">SUBJECT2</a></div><br>
                            <div class="main-btn"><a href="#3">SUBJECT3</a></div><br>
                            <div class="main-btn"><a href="#3">SUBJECT4</a></div><br>-->
                      </div>
                    </div>
                   
                    </div> -->
                </div>
            </div>
          
          <div class="slide" id="3">
            <div class="content third-content">
                <div class="container-fluid">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="first-section">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="left-content">
                                                <h2>Attendance
                                                
                                                                                                 <?php
require "start.php";

// $student_id=$_POST["student_id"];
// $subject_id=$_POST["subject_id"];
$student_id=$_POST["student_id"];
//$subject_id='su2';

$sql_query = "select sum(attendance_status='PRESENT')*100/count(*) as attendance_percent from attendance where student_id='$student_id';";
$sql_query2 = "select max(time),attendance_status from attendance where student_id='$student_id';";
$result =mysqli_query($con,$sql_query);
$result2=mysqli_query($con,$sql_query2);
while($row = mysqli_fetch_assoc($result))
{
echo $row['attendance_percent'];
echo"%";
echo"\n";
}
while($row = mysqli_fetch_assoc($result2))
{
    echo "Last marked attendance at: ";
    echo $row['max(time)'];
    echo "\n";
    echo "Attendance Status: ";
    echo $row['attendance_status'];
}
?>
                                                
                                                </h2>
                                                <table style="border:1px solid white">
                                                <tr>
                                                    <th>Subject </th>
                                                <th>Total Lectures attended</th>
                                                 <th>Total Lectures Delivered</th>
                                                 </tr>
                                                 <?php
require "start.php";

// $student_id=$_POST["student_id"];
// $subject_id=$_POST["subject_id"];
$student_id=$_POST["student_id"];
//$subject_id='su2';

$sql_query = "select subject_id from teacher_student_subject where student_id='$student_id';";
$result =mysqli_query($con,$sql_query);
while($row = mysqli_fetch_assoc($result))
{
    $query="select subject_id,count(*) as total from attendance where student_id='$student_id' and subject_id='".$row['subject_id']."' and attendance_status='PRESENT';";
    $query2="select subject_id,count(*) as fulltotal from attendance where student_id='$student_id' and subject_id='".$row['subject_id']."';";
    $res=mysqli_query($con,$query);
    
    while($rowin = mysqli_fetch_assoc($res))
    {
        $res2=mysqli_query($con,$query2);
        // echo $rowin['student_id'];
        // echo "\n";
        ?>
        <tr>
            <td>
         <?php echo $row['subject_id']; ?>
         </td> <td><?php
        //echo "\n";
        // echo $rowin['attendance_status'];
        // echo "\n";
        echo $rowin['total'];?> </td> <td> <?php
        //echo "\n";
        while($rowin2=mysqli_fetch_assoc($res2))
        {
            //echo "Total";
            echo $rowin2['fulltotal']; ?> </td> </tr> <?php
        }
    }
}
?>
                                                </table>
                                                <!-- <div class="main-btn"><a href="#4">Continue Reading</a></div> -->
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <!-- <div class="right-image">
                                                <img src="img/first_service.jpg" alt="first service">
                                            </div> -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="second-section">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="left-image">
                                                <!-- <img src="img/second_service.jpg" alt="second service"> -->
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <!-- <div class="right-content">
                                                <h2>Maecenas eu purus eu sapien</h2>
                                                <p>Sed vitae felis in lorem mollis mollis eget in leo. Donec commodo, ex nec rutrum venenatis, nisi nisl malesuada magna, sed semper ipsum enim a ipsum. Aenean in ante vel mi molestie bibendum. Quisque sit amet lacus in diam pretium faucibus. Cras vel justo lorem.</p>
                                                <div class="main-btn"><a href="#4">Continue Reading</a></div>
                                            </div> -->
                                        <!-- </div> -->
                                    </div>
                                </div> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          </div>
          </div>
       
          
        </div>

        <div class="footer">
          <div class="content">
              <p></p>
          </div>
        </div>

    
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.11.2.min.js"><\/script>')</script>

    <script src="js/vendor/bootstrap.min.js"></script>
    
    <script src="js/datepicker.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js" type="text/javascript"></script>
    <script type="text/javascript">
    $(document).ready(function() {

        

        // navigation click actions 
        $('.scroll-link').on('click', function(event){
            event.preventDefault();
            var sectionID = $(this).attr("data-id");
            scrollToID('#' + sectionID, 750);
        });
        // scroll to top action
        $('.scroll-top').on('click', function(event) {
            event.preventDefault();
            $('html, body').animate({scrollTop:0}, 'slow');         
        });
        // mobile nav toggle
        $('#nav-toggle').on('click', function (event) {
            event.preventDefault();
            $('#main-nav').toggleClass("open");
        });
    });
    // scroll function
    function scrollToID(id, speed){
        var offSet = 0;
        var targetOffset = $(id).offset().top - offSet;
        var mainNav = $('#main-nav');
        $('html,body').animate({scrollTop:targetOffset}, speed);
        if (mainNav.hasClass("open")) {
            mainNav.css("height", "1px").removeClass("in").addClass("collapse");
            mainNav.removeClass("open");
        }
    }
    if (typeof console === "undefined") {
        console = {
            log: function() { }
        };
    }
    </script>
</body>
</html>