<?php
require "start.php";
	$student_id=$_POST["student_id"];
	$student_password=$_POST["student_password"];
	$student_name=$_POST["student_name"];
	$student_batch=$_POST["student_batch"];
	$student_contact=$_POST["student_contact"];
$sql_query = "INSERT INTO `students` (`student_id`, `student_password`, `student_name`, `student_batch`, `student_contact`) VALUES ('$student_id', '$student_password', '$student_name', '$student_batch', '$student_contact');";
if(mysqli_query($con,$sql_query))
{
echo "Register Success";
}
else
{
echo "Register Unsuccess";
}
?>