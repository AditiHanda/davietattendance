<?php
require "start.php";

// $student_id=$_POST["student_id"];
// $subject_id=$_POST["subject_id"];
$student_id='Nishant';
$subject_id='su2';

$sql_query = "select subject_id from student_subject where student_id='$student_id';";
$result =mysqli_query($con,$sql_query);
while($row = mysqli_fetch_assoc($result))
{
    $query="select subject_id,count(*) as total from attendance where student_id='Nishant' and subject_id='".$row['subject_id']."' and attendance_status='PRESENT';";
    $query2="select subject_id,count(*) as fulltotal from attendance where student_id='Nishant' and subject_id='".$row['subject_id']."';";
    $res=mysqli_query($con,$query);
    
    while($rowin = mysqli_fetch_assoc($res))
    {
        $res2=mysqli_query($con,$query2);
        // echo $rowin['student_id'];
        // echo "\n";
         echo $rowin['subject_id'];
        echo "\n";
        // echo $rowin['attendance_status'];
        // echo "\n";
        echo $rowin['total'];
        echo "\n";
        while($rowin2=mysqli_fetch_assoc($res2))
        {
            echo "Total";
            echo $rowin2['fulltotal'];
        }
    }
}
?>