<?php
    //connect to database
    //include_once('bla.php');

    // Select database
    //mysql_select_db("test") or die(mysql_error());

    // SQL query
    $teacherId = $_POST['teacherId'];
    $studentId = $_POST['studentId'];
    $subjectId = $_POST['subjectId'];
    echo "$teacherId";
    //$strSQL = 'bla bla query';
    //mysql_close();
?>