<?php
$con=mysqli_connect("localhost","id11406858_aditihanda","aditihanda","id11406858_davietattendance");
if(!$con)
{
	echo "Error ...".mysqli_connect_error();
}
else
{
 //echo "Mubarkaan";
}
?>