<?php
require "start.php";
	$teacher_id=$_POST["teacher_id"];
	$student_id=$_POST["student_id"];
	$subject_id=$_POST["subject_id"];
	$time=$_POST["time"];
	$attendance_status=$_POST["attendance_status"];
$sql_query = "insert into attendance values('$teacher_id','$student_id','$subject_id','$time','$attendance_status');";
if(mysqli_query($con,$sql_query))
{
echo "Success";
}
else
{
echo "Unsuccess";
}
?>