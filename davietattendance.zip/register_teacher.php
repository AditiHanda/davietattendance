<?php
require "start.php";
	$teacher_id=$_POST["teacher_id"];
	$teacher_password=$_POST["teacher_password"];
	$teacher_name=$_POST["teacher_name"];
	$teacher_contact=$_POST["teacher_contact"];
$sql_query = "INSERT INTO `teachers` (`teacher_id`, `teacher_password`, `teacher_name`, `teacher_contact`) VALUES ('$teacher_id', '$teacher_password', '$teacher_name', '$teacher_contact');";
if(mysqli_query($con,$sql_query))
{
echo "Register Success";
}
else
{
echo "Register Unsuccess";
}
?>