<?php
require "start.php";

$teacher_id=$_POST["teacher_id"];

$sql_query = "select * from teacher_student_subject where teacher_id='$teacher_id';";
$result =mysqli_query($con,$sql_query);
while($row = mysqli_fetch_assoc($result))
{
//echo "true;";
echo $row['subject_id'];
echo "\n";
}
?>