<?php
require "start.php";

$id=$_POST["id"];
$password=$_POST["password"];

$sql_query1 = "select * from teachers where teacher_id='$id' and teacher_password='$password';";
$result1 =mysqli_query($con,$sql_query1);
$sql_query2 = "select * from students where student_id='$id' and student_password='$password';";
$result2 =mysqli_query($con,$sql_query2);
if($row = mysqli_fetch_assoc($result1))
{
echo "Teacher Login Success";
echo $row['teacher_id'];
?>
<?php
}
else if($row = mysqli_fetch_assoc($result2))
{
echo "Student Login Success";
echo $row['student_id'];
?>
<?php
}
else
{
    echo "Error Login";
}
?>