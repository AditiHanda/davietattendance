<html>
    <head><title>SignUp Page for Teachers</title></head>
    <style>
    .bg-img {
  /* The image used */
  background-image: url("maxresdefault.jpg");

  min-height: 640px;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
}
.container1{
position: absolute;
  right: 424px;
  margin: 20px;
  max-width: 300px;
  padding: 16px;

  background-color: white;
    
}
input[type=text], input[type=password],input[type=email] {
  width: 100%;
  padding: 12px 20px;
  /* margin: 8px 0; */
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: rgb(168, 59, 59);
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}
.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
    </style>
    <body>
        <div class="bg-img">
            <form action="register_teacher.php" class="container1" method="POST">
                    <div class="container">
                            <b>SIGN UP FOR TEACHERS</b><BR>
                            <label for="uname"><b>Teacher ID</b></label>
                            <input type="text" placeholder="Enter Username" name="teacher_id" required>
                            <label for="psw"><b>Password</b></label>
                            <input type="password" placeholder="Enter Password" name="teacher_password" required>
                            <label for="name"><b>Name</b></label>
                            <input type="text" placeholder="Enter your name" name="teacher_name" required>

                            <label for="contact"><b>Contact</b></label>
                            <input type="text" placeholder="Enter your contact no" name="teacher_contact" required>
                            
                            


                            
                                
                            <button type="submit">SignUp</button>
                            
                              
                          </div>
         </form></div>


    </body>
    
</html>