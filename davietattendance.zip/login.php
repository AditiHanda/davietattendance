<?php
require "start.php";

$id=$_POST["id"];
$password=$_POST["password"];

$sql_query1 = "select * from teachers where teacher_id='$id' and teacher_password='$password';";
$result1 =mysqli_query($con,$sql_query1);
$sql_query2 = "select * from students where student_id='$id' and student_password='$password';";
$result2 =mysqli_query($con,$sql_query2);
$v;
if($id=='admin'&&$password=='admin')
{
    header("Location: admin_login.php");
}
else if($row = mysqli_fetch_assoc($result1))
{
// echo "Teacher Login Success";
// echo $row['teacher_id'];
// session_start();
// $_SESSION["email"] = $row['teacher_id'] ;
// // header("Location: teacher.php");
?>
<form id="jsform1" action="teacher.php" method="POST">
<input type="hidden" name="teacher_id" value='<?php echo $row['teacher_id'];?>' >
<input type="hidden" name="teacher_name" value='<?php echo $row['teacher_name'];?>' >
<input type="hidden" name="teacher_contact" value='<?php echo $row['teacher_contact'];?>' >
</form>
<script type="text/javascript">
  document.getElementById('jsform1').submit();
</script>
<?php
}
else if($row = mysqli_fetch_assoc($result2))
{
// echo "Student Login Success";
// // echo $row['student_id'];
// header("Location: student.php");
?>
<form id="jsform2" action="student.php" method="POST">
<input type="hidden" name="student_id" value=<?php echo $row['student_id'];?> >
<input type="hidden" name="student_name" value=<?php echo $row['student_name'];?> >
<input type="hidden" name="student_batch" value=<?php echo $row['student_batch'];?> >
<input type="hidden" name="student_contact" value=<?php echo $row['student_contact'];?> >
</form>
<script type="text/javascript">
  document.getElementById('jsform2').submit();
</script>
<?php
}
else
{
    echo "Error Login";
}
?>